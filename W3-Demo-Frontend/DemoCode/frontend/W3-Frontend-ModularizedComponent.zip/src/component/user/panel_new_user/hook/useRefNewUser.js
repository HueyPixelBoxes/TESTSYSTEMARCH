import { useRef } from 'react';
import addNewUser from '../api/addUser';

const useRefNewUser = () => {

    const userFormRef = useRef(null);

    const constructUser = () => {
        const formData = new FormData(userFormRef.current);

        // Convert FormData to object
        const formValues = Object.fromEntries(formData.entries());

        userFormRef.current.reset();

        return formValues
    }

    const submitUser = async (e, reloadUsersFunc) => {
        e.preventDefault();

        const user = constructUser();

        let response = await addNewUser(user);

        if (response.status == 200) {
            reloadUsersFunc();
        }
        // handle error cases here
    }
    
    return {
        userFormRef,
        submitUser
    }
}

export default useRefNewUser;

