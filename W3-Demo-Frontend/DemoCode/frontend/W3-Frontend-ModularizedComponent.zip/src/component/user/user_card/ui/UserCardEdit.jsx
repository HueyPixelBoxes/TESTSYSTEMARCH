import { Save, X } from "@mui/icons-material"
import { Button, Input } from "@mui/material"


const UserCardEdit = ({ 
    setIsEditing, 
    editHook,
    reloadTableFunction 
}) => {

    const { 
        editedUser, 
        changeUserData, 
        updateUser 
    } = editHook;
    
    return (
        <form className="space-y-3" 
                onClick={(e) => updateUser(e, reloadTableFunction)}
        >
                <Input
                    name="firstName"
                    value={editedUser.firstName}
                    onChange={changeUserData}
                    placeholder="First Name"
                    className="mr-2 w-1/6"
                />
                <Input
                    name="lastName"
                    value={editedUser.lastName}
                    onChange={changeUserData}
                    placeholder="Last Name"
                    className="mr-2 w-1/6"
                />
                <Input
                    name="email"
                    type="email"
                    value={editedUser.email}
                    onChange={changeUserData}
                    placeholder="Email"
                    className="mr-2 w-auto"
                />

                <Input
                    name="id"
                    type="hidden"
                    value={editedUser.id}
                    className="dp-none"
                />
            
            
            <div className="flex justify-end space-x-2">
                <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => setIsEditing(false)}
                >
                    <X className="h-4 w-4 mr-1" />
                    Cancel
                </Button>

                <Button 
                    size="sm"
                    type="submit"
                    onClick={() => setIsEditing(false)}
                >
                    <Save className="h-4 w-4 mr-1" />
                    Save
                </Button>
            </div>
        </form>
    )
}

export default UserCardEdit