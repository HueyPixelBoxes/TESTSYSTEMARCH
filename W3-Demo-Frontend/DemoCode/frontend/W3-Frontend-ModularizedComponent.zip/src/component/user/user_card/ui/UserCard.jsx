import { useState } from "react"
import UserCardView from "./UserCardView"
import UserCardEdit from "./UserCardEdit"
import useRefEditUser from "../hook/useRefEditUser"

const UserCard = ({ item, reloadTableFunction }) => {
    
    const [isEditing, setIsEditing] = useState(false)

    const editHook = useRefEditUser(item);

    return (
        <div>
            { 
                // <UserCardView 
                //     item={item} 
                //     reloadTableFunction={reloadTableFunction} 
                // />

                !isEditing
                ? ( UserCardView ({
                        item, 
                        setIsEditing,
                        reloadTableFunction
                    }) )
                    
                : ( UserCardEdit ({
                        setIsEditing,
                        editHook,
                        reloadTableFunction
                    }) )
            }
        </div>
        
            
    )
    

}

export default UserCard
