import sendHttpRequest from "../../../../http_call/HttpRequest";
import CustomerUrlConfig from "../../../../service_url/CustomerUrlConfig";

async function editUser(editedUser) {

    let response = await sendHttpRequest(
        CustomerUrlConfig.CUSTOMER_SERVICE_URL,
        "PUT",
        JSON.stringify(editedUser)
    )

    return response
}

export default editUser