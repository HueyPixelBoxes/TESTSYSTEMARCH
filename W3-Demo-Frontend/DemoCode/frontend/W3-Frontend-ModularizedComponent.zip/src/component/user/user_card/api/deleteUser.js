import sendHttpRequest from "../../../../http_call/HttpRequest";
import CustomerUrlConfig from "../../../../service_url/CustomerUrlConfig";

export default async function deleteUser(userId) {

    let response = await sendHttpRequest(
        `${CustomerUrlConfig.CUSTOMER_SERVICE_URL}/${userId}`,
        "DELETE"
    )

    return response
    
}