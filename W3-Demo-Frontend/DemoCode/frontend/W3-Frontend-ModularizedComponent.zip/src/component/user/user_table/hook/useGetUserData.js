import { useState, useEffect } from 'react'
import loadUserData from "../api/UserTableService"

function useGetUserData () {
    const [items, setItems] = useState([])

    async function fetchItems () {
        const result = await loadUserData()
        setItems(result)
    }

    useEffect(() => {
        fetchItems()
    }, [])

    return { items, fetchItems }
}

export default useGetUserData