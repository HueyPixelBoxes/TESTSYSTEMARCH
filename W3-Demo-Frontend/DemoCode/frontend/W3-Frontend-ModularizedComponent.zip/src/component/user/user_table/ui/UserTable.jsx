
import useGetUserData from "../hook/useGetUserData";
import UserCard from "../../user_card/ui/UserCard";
import UserPanel from "../../panel_new_user/ui/UserPanel";

export default function UserTable() {
    
    const {items, fetchItems} = useGetUserData()
    
    return (
        <>
            <UserPanel reloadFunction={fetchItems}/>

            <div className="
                grid
                sm:grid-cols-1 md:grid-cols-2 
                    lg:grid-cols-3 xl:grid-cols-4
                mx-auto p-4
                gap-4 
            ">
                
                {
                    items.map((item, index) => (
                        <UserCard item={item} key={index} 
                            reloadTableFunction={fetchItems}/>
                    ))
                } 

            </div>

            
        </>
    );
}
