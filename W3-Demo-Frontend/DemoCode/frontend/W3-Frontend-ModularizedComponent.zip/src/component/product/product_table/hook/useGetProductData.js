import { useState, useEffect } from 'react'
import loadProductData from "../api/ProductApi";

function useGetProductData () {
    const [items, setItems] = useState([])

    async function fetchItems () {
        const result = await loadProductData()
        setItems(result)
    }

    useEffect(() => {
        fetchItems()
    }, [])

    return { items, fetchItems }
}

export default useGetProductData