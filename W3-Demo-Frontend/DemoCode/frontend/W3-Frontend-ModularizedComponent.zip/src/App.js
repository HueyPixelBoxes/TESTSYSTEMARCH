import ProductTable from "./component/product/product_table/ui/ProductTable";
import UserPage from "./page/UserPage";

function App() {
  return (
    <div className="App">

      <UserPage />

      {/* <ProductTable /> */}

    </div>
  );
}

export default App;
