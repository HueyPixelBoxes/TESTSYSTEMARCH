import UserTable from "../component/user/user_table/ui/UserTable";

export default function UserPage() {
    return (
      <UserTable />
    );
}