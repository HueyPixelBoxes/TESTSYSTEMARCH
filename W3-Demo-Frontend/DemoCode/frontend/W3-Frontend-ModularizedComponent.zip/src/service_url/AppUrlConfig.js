const HOST_PORT = 8081
const HOST_URL = "http://localhost:" + HOST_PORT

export default HOST_URL