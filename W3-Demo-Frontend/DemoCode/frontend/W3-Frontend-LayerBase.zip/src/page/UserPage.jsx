import UserTable from "../component/user/UserTable";
import UserTableFullHouse from "../component/user_all_in_one/UserTableFullHouse";

export default function UserPage() {
    return (
      <UserTable />
      // <UserTableFullHouse /> // Uncomment to use the all-in-one user table
    );
}