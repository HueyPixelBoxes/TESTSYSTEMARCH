import UserPage from "./page/UserPage";

function App() {
  return (
    <div className="App">

      <UserPage />      
      
    </div>
  );
}

export default App;
