import deleteUser from "../../api/user/deleteUser";

export default async function sendDeleteRequest(user, reloadUsersFunc) {
    const response = await deleteUser(user.id);
    
    if (response.status === 200) {
        reloadUsersFunc();
    }
}