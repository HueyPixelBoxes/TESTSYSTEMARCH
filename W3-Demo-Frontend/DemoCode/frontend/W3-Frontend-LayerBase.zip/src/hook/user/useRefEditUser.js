import { useState } from 'react';
import editUser from '../../api/user/editUser';

const useRefEditUser = (uneditedUser) => {

    const [editedUser, setEditedUser] = useState(uneditedUser);

    const changeUserData = (e) => {
        const { name, value } = e.target;
        
        setEditedUser(prevUser  => ({
            ...prevUser,
            [name]: value
        }));
    };

    const updateUser = async (e, reloadUsersFunc) => {
        e.preventDefault();

        let response = await editUser(editedUser);

        if (response.status == 200) {
            reloadUsersFunc();
        }
        // handle error cases here
    }
    
    return {
        editedUser,
        setEditedUser,
        changeUserData,
        updateUser
    }
}

export default useRefEditUser;

