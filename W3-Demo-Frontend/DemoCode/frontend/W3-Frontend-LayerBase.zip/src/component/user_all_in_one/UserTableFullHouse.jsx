
import UserCardEditFullHouse from "./UserCardEditFullHouse";
import UserCardViewFullHouse from "./UserCardViewFullHouse";
import InputField from "../../component_reusable/input_field/InputField";

import { useEffect, useRef, useState } from "react";

import sendHttpRequest from "../../http_call/HttpRequest";
import CustomerUrlConfig from "../../service_url/CustomerUrlConfig";

export default function UserTableFullHouse() {
    
    const [items, setItems] = useState([])

    const [isEditing, setIsEditing] = useState(false)

    const userFormRef = useRef(null);

    async function fetchItems () {
        const result = await loadUserData()
        setItems(result)
    }

    const constructUser = () => {
        const formData = new FormData(userFormRef.current);

        // Convert FormData to object
        const formValues = Object.fromEntries(formData.entries());

        userFormRef.current.reset();

        return formValues
    }

    const submitUser = async (e, reloadUsersFunc) => {
        e.preventDefault();

        const user = constructUser();

        let response = await addNewUser(user);

        if (response.status == 200) {
            reloadUsersFunc();
        }
        // handle error cases here
    }

    const loadUserData = async () => {
        const response = await sendHttpRequest(
            CustomerUrlConfig.CUSTOMER_SERVICE_URL
        )
    
        if (response.status == 200) {
            return response.json;
        } 
        else if (response.status >= 500) {
            return "Server Error"
        } 
        else if (response.status >= 400) {
            return "Client Error"
        }
    }

    async function addNewUser(newUser) {

        let response = await sendHttpRequest(
            CustomerUrlConfig.CUSTOMER_SERVICE_URL,
            "POST",
            JSON.stringify(newUser)
        )

        return response
        
    }

    useEffect(() => {
        fetchItems()
    }, [])
    
    
    return (
        <>
            <div>
                <form ref={userFormRef} 
                    onSubmit={(e) => submitUser(e, fetchItems)}
                    className="flex flex-row gap-2"
                >
                    <InputField 
                        attrName="firstName"
                        type="text"
                        placeholder="First Name"
                    />
                    
                    <InputField 
                        attrName="lastName"
                        type="text" 
                        placeholder="Last Name" 
                    />
    
                    <InputField 
                        attrName="email"
                        type="email" 
                        placeholder="Email" 
                    />
    
                    <InputField 
                        attrName="balance"
                        type="number" 
                        placeholder="Balance" 
                    />
                    
                    <button 
                        className=" text-white text-xl 
                                    bg-green-500 rounded
                                    items-center justify-center
                                    px-4 w-auto h-12"
                    >
                        Add Product
                    </button>
                </form>
            </div>

            <div className="
                grid
                sm:grid-cols-1 md:grid-cols-2 
                    lg:grid-cols-3 xl:grid-cols-4
                mx-auto p-4
                gap-4 
            ">
                
                {
                    items.map((item, index) => (
                        // <UserCard item={item} key={index} 
                        //     fetchItems={fetchItems}/>
                        <div>
                            { 
                                !isEditing
                                ? 
                                ( 
                                    UserCardViewFullHouse ({
                                        item, 
                                        setIsEditing,
                                        reloadTableFunction: fetchItems
                                    }) 
                                )
                                : 
                                ( 
                                    UserCardEditFullHouse ({
                                        setIsEditing,
                                        uneditedUser: item,
                                        reloadTableFunction: fetchItems
                                    }) 
                                    
                                )
                            }
                        </div>
                    ))
                } 

            </div>

            
        </>
    );
}
