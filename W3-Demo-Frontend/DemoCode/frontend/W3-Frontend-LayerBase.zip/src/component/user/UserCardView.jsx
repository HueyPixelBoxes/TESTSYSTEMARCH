import { Delete, Edit } from "@mui/icons-material"
import { Button } from "@mui/material"
import sendDeleteRequest from "../../hook/user/deleteUser"

const UserCardView = ({ item, setIsEditing, reloadTableFunction }) => {
    
    return (
        <div key={item.id} 
            className="
                relative
                border p-4 m-1 rounded shadow
                hover:border-blue-500
        ">
            <div className="relative flex justify-end h-4 w-full">
                <Button 
                    variant="primary"
                    sx={{ minWidth: '10px' }}
                    className="right-2 transition-opacity"
                    onClick={() => setIsEditing(true)}
                >
                    <Edit className="h-4 w-2 text-blue-500" />
                </Button>

                <Button 
                    variant="primary"
                    sx={{ minWidth: '10px' }}
                    className="absolute w-2 right-0 transition-opacity"
                    onClick={() => sendDeleteRequest(item, reloadTableFunction)}
                >
                    <Delete className="h-4 w-2 text-red-500" />
                </Button>
            </div>

            <h2 className="text-lg font-bold w-full">
                {item.firstName + " " + item.lastName} 
            </h2>

            <p>Email: {item.email}</p>

        </div>
    )
}

export default UserCardView
