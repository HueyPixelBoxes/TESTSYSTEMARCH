import { useState } from "react"
import UserCardView from "./UserCardView"
import UserCardEdit from "./UserCardEdit"
import useRefEditUser from "../../hook/user/useRefEditUser"

const UserCard = ({ item, reloadTableFunction }) => {
    
    const [isEditing, setIsEditing] = useState(false)

    const editHook = useRefEditUser(item);

    return (
        <div>
            { 

                !isEditing
                ? ( UserCardView ({
                        item, 
                        setIsEditing,
                        reloadTableFunction
                    }) )
                    
                : ( UserCardEdit ({
                        setIsEditing,
                        editHook,
                        reloadTableFunction
                    }) )
            }
        </div>
        
            
    )
    

}

export default UserCard
