
import InputField from "../../component_reusable/input_field/InputField";
import useRefNewUser from "../../hook/user/useRefNewUser";

const UserPanel = ({reloadFunction}) => {
    
    const {userFormRef, submitUser} = useRefNewUser();

    return (
        <div>
            <form ref={userFormRef} 
                onSubmit={(e) => submitUser(e, reloadFunction)}
                className="flex flex-row gap-2"
            >
                <InputField 
                    attrName="firstName"
                    type="text"
                    placeholder="First Name"
                />
                
                <InputField 
                    attrName="lastName"
                    type="text" 
                    placeholder="Last Name" 
                />

                <InputField 
                    attrName="email"
                    type="email" 
                    placeholder="Email" 
                />

                <InputField 
                    attrName="balance"
                    type="number" 
                    placeholder="Balance" 
                />
                
                <button 
                    className=" text-white text-xl 
                                bg-green-500 rounded
                                items-center justify-center
                                px-4 w-auto h-12"
                >
                    Add Product
                </button>
            </form>
        </div>
        
    );
};

export default UserPanel;