import sendHttpRequest from "../../http_call/HttpRequest";
import CustomerUrlConfig from "../../service_url/CustomerUrlConfig";

async function addNewUser(newUser) {

    let response = await sendHttpRequest(
        CustomerUrlConfig.CUSTOMER_SERVICE_URL,
        "POST",
        JSON.stringify(newUser)
    )

    return response
    
}

export default addNewUser