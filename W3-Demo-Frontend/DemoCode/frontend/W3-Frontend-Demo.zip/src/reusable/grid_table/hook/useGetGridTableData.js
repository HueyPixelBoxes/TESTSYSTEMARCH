import { useState, useEffect } from 'react'

function useGridTableLoadData (loadItemApi) {
    const [items, setItems] = useState([])

    async function fetchItems () {
        const result = await loadItemApi()
        setItems(result)
    }

    useEffect(() => {
        fetchItems()
    }, [])

    return { items, fetchItems }
}

export default useGridTableLoadData