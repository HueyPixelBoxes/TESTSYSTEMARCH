
import useGridTableLoadData from "./hook/useGetGridTableData";

const GridTable = ({
        CardComponent, 
        loadItemApi,
        NewItemPanel
}) => {

    const { items, fetchItems }  = useGridTableLoadData(loadItemApi)

    console.log("GridTable items:", items);
    return (
        <>
            {NewItemPanel ? <NewItemPanel reloadFunction={fetchItems}/> : null}

            <div className="
                grid
                sm:grid-cols-1 md:grid-cols-2 
                    lg:grid-cols-3 xl:grid-cols-4
                mx-auto p-4
                gap-4 
            ">
                
                {items.map((item, index) => (
                    <CardComponent item={item} key={index} />
                ))} 

            </div>
            
        </>
    );
};

export default GridTable;
