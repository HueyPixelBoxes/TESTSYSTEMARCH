import GridTable from "../../../reusable/grid_table/GridTable";
import loadProductData from "./api/ProductApi";
import ProductCard from "../product_card/ProductCard";
import UserPanel from "../../user/user_panel/UserPanel";

export default function ProductTable() {
    return (
        <GridTable CardComponent={ProductCard} 
                    loadItemApi={loadProductData}
                    />
    );
}
