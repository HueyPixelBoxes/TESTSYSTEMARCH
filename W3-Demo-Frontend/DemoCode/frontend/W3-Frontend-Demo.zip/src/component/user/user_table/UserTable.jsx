import GridTable from "../../../reusable/grid_table/GridTable";
import UserPanel from "../user_panel/UserPanel";
import loadUserData from "./api/UserTableService";
import UserCard from "../user_card/UserCard";

export default function UserTable() {

    return (
        <GridTable CardComponent={UserCard} 
                    loadItemApi={loadUserData}
                    NewItemPanel={UserPanel}
        />
    );
}
