import ProductTable from "./component/product/product_table/ProductTable";
import UserTable from "./component/user/user_table/UserTable";

function App() {
  return (
    <div className="App">

      <UserTable />      
      {/* <ProductTable />       */}
      
    </div>
  );
}

export default App;
