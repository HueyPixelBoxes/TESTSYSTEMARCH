import HOST_URL from "./AppUrlConfig";

const CUSTOMER_SERVICE_URL = `${HOST_URL}/customers`

export default { CUSTOMER_SERVICE_URL }